Kitty Recolored Parasols Props | RedM

This package includes recolored parasol props. The models are the same as the base game parasol props, only textures are edited. Now you can use them in new colors.

Number of props:7

Prop names:

k_p_parasol02x_custom_01
k_p_parasol02x_custom_02
k_p_parasol02x_custom_03
k_p_parasol02x_custom_04
k_p_parasol02x_custom_05
k_p_parasol02x_custom_06
k_p_parasol02x_custom_07

YTYP file: k_p_parasol02_custom.ytyp
Texture file: k_p_parasol02x_custom_txd.ytd

Installation for the props: 
	      1. Unzip the file and drag into your resources.
	      2. Ensure the resource.

Each of the props can be placed with Spooner.
	      1. Open Spooner
              2. Go to Objects
              3. Type the correct name of the prop
              4. Go to "Spawn by name"
              5. Press "E" on your keyboard

